import React from 'react';
import { Table, Button } from 'semantic-ui-react';
import axios from 'axios';
import { useState, useEffect } from "react";
import { Link } from 'react-router-dom';


const Read = () => {
    const [Info, setInfo] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5000/info')
            .then((res) => {
                setInfo(res.data);
            });
    });


    const setData = (id, title, description, creator) => {
        console.log(id, title, description, creator);

        localStorage.setItem('ID', id);
        localStorage.setItem('Title', title);
        localStorage.setItem('Description', description);
        localStorage.setItem('Creator', creator);
    }

    const getData = () => {
        axios.get('http://localhost:5000/info')
            .then((res) => {
                setInfo(res.data);
            });
    }

    const onDelete = (id) => {
        axios.delete(`http://localhost:5000/info/${id}`)
            .then(() => {
                getData();
            });
    }



    return (

        <div>
            <Table celled>
                <Table.Header>
                    <Table.Row>
                        <Table.HeaderCell>ID</Table.HeaderCell>
                        <Table.HeaderCell>Title</Table.HeaderCell>
                        <Table.HeaderCell>Creator</Table.HeaderCell>
                        <Table.HeaderCell>Description</Table.HeaderCell>
                        <Table.HeaderCell>Update</Table.HeaderCell>
                        <Table.HeaderCell>Delete</Table.HeaderCell>
                    </Table.Row>
                </Table.Header>

                <Table.Body>
                    {Info.map((data, index) => {
                        return (
                            <Table.Row key={index}>
                                <Table.Cell>{index}</Table.Cell>
                                <Table.Cell>{data.title}</Table.Cell>
                                <Table.Cell>{data.description}</Table.Cell>
                                <Table.Cell>{data.creator}</Table.Cell>
                                <Table.Cell>
                                    <Link to='/update'>
                                        <Button
                                            color="green"
                                            onClick={() => setData(data._id, data.title, data.description, data.creator)}>
                                            Update
                                        </Button>
                                    </Link>
                                </Table.Cell>
                                <Table.Cell>
                                    <Button color="red" onClick={() => onDelete(data._id)}>Delete</Button>
                                </Table.Cell>
                            </Table.Row>
                        )
                    })}

                </Table.Body>
            </Table>
        </div>

    )
}

export default Read