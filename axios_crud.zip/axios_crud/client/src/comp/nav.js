import React from 'react'
import { Link } from 'react-router-dom';

const Nav = () => {
    return (
        <div>

            <Link to='/'>
                <h3>Home</h3>
            </Link>

            <Link to='/read'>
                <h3>Read</h3>
            </Link>


            <Link to='/update'>
                <h3>Update</h3>
            </Link>

            {/* <Link to='/delete'>
                <h3>Delete</h3>
            </Link> */}


           

        </div>
    )
}

export default Nav