import React from 'react'
import { Button, Form, Menu } from 'semantic-ui-react'
import { useState } from "react";
import axios from 'axios'
import { useNavigate } from 'react-router-dom';




const Create = () => {

    const navigate = useNavigate();

    const [Title, setTitle] = useState('');
    const [Description, setDescription] = useState('');
    const [Creator, setCreator] = useState('');



    const callDataToApi = () => {

        axios.post('http://localhost:5000/info', {
            title: Title, description: Description, creator: Creator
        }).then(() => {
            navigate('/read')
        })

    }


    return (
        <div>
            <div className='main'>

                <h1>Create A Record</h1>
                <Form >
                    <Form.Field>
                        <label>Title</label>
                        <input name='title' onChange={(e) => setTitle(e.target.value)} placeholder='Title' />
                    </Form.Field>

                    <Form.Field>
                        <label>Description</label>
                        <input name='description' onChange={(e) => setDescription(e.target.value)} placeholder='Description' />
                    </Form.Field>

                    <Form.Field>
                        <label>Creator</label>
                        <input name='creator' onChange={(e) => setCreator(e.target.value)} placeholder='Creator' />
                    </Form.Field>

                    <Button onClick={callDataToApi} type='submit'>Submit</Button>
                </Form>
            </div>

        </div>
    )
}

export default Create