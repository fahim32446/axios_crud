import React from 'react'
import { Button, Form } from 'semantic-ui-react'
import { useState, useEffect } from "react";
import axios from 'axios'
import { useNavigate } from 'react-router-dom';


const Update = () => {
    const navigate = useNavigate();
    
    const [Title, setTitle] = useState('');
    const [Description, setDescription] = useState('');
    const [Creator, setCreator] = useState('');
    const [ID, setID] = useState(null);



    const callDataToApi = () => {
        

        axios.patch(`http://localhost:5000/info/${ID}`, {
            title: Title, description: Description, creator: Creator
        }).then(()=>{
            navigate('/read');
            localStorage.clear();

        })

    }

    useEffect(() => {
        setTitle(localStorage.getItem('Title'));
        setDescription(localStorage.getItem('Description'));
        setCreator(localStorage.getItem('Creator'));
        setID(localStorage.getItem('ID'));
    }, []);

  


    return (
        <div>
            <div className='main'>
                <Form >
                    <Form.Field>
                        <label>Title</label>
                        <input value={Title} name='title' onChange={(e) => setTitle(e.target.value)} placeholder='Title' />
                    </Form.Field>

                    <Form.Field>
                        <label>Description</label>
                        <input value={Description} name='description' onChange={(e) => setDescription(e.target.value)} placeholder='Description' />
                    </Form.Field>

                    <Form.Field>
                        <label>Creator</label>
                        <input value={Creator} name='creator' onChange={(e) => setCreator(e.target.value)} placeholder='Creator' />
                    </Form.Field>

                    <Button onClick={callDataToApi} type='Update'>Update</Button>
                </Form>
            </div>

        </div>
    )
}

export default Update