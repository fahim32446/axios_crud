import './App.css';
import Read from './comp/read.js'
import Create from './comp/create.js'
import Update from './comp/update.js'
import Delete from './comp/delete.js'
import Nav from './comp/nav.js'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Router>

      <div className=''>
        <div>
          <h3>React Crud Operations</h3>
        </div>
      <Nav />

        <Routes>

         
          <Route exact path='/' element={<Create />} />
          <Route exact path='/read' element={<Read />} />

          <Route exact path='/update' element={<Update />} />
          <Route exact path='/delete' element={<Delete />} />
        </Routes>





      </div>
    </Router>



  );
}

export default App;
