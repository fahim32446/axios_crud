import mongoose from "mongoose";

const infoSchema = mongoose.Schema({

    title : String,
    description: String,
    creator: String,
    tags: [String],


});

const infoMessage = mongoose.model('infoMessage', infoSchema);
export default infoMessage;