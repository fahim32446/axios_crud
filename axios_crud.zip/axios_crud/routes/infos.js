import express from 'express'
import {getInfo, createInfo, patchInfo, deleteInfo} from '../controller/infos.js'

const router = express.Router();

router.get('/', getInfo);
router.post('/', createInfo);
router.patch("/:id", patchInfo);
router.delete('/:id', deleteInfo);


export default router;