import express from 'express'
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import cors from 'cors'

import INFO from './routes/infos.js'


const app = express();
app.use(cors());
app.use(express.json());

const port = process.env.port || 5000;


const ATLAS_URI = 'mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false'
mongoose.connect(ATLAS_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => app.listen(port, (req, res) => {
        console.log(`Server Run on port ${port}`);
    }))
    .catch((error) => console.log(error))


app.get('/', (req, res) => {
    res.send('index.js');
})

app.use('/info', INFO);


