import infoMessage from '../models/infoMessage.js';





export const getInfo = async (req, res) => {
    try {

        const infoMessages = await infoMessage.find();
        res.status(200).json(infoMessages);


    } catch (error) {
        res.status(404).json(error)
    }
};




export const createInfo = async (req, res) => {

    const info = req.body;
    const newInfo = new infoMessage(info);

    try {

        await newInfo.save();
        res.status(201).json(newInfo)

    } catch (error) {

    }
};


export const patchInfo = async(req, res)=>{
    try {
        const _id = req.params.id;
        const patch = await infoMessage.findByIdAndUpdate(_id,req.body);
        res.send(patch);
    } catch (error) {
       
       
    }
}


export const deleteInfo = async(req, res)=>{
    try {
        const _id = req.params.id;
        const del = await infoMessage.findByIdAndDelete(_id,req.body);
        res.status(200).send(del);
        res.json("deleted")
    } catch (error) {
        res.status(400).send(e);
    }
}